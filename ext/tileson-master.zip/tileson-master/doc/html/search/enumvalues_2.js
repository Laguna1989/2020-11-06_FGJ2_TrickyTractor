var searchData=
[
  ['cbor_1362',['cbor',['../namespacenlohmann_1_1detail.html#aa554fc6a11519e4f347deb25a9f0db40aaf9de350d652f0c9055ddab514bd23ea',1,'nlohmann::detail']]],
  ['color_1363',['Color',['../namespacetson.html#a072f9f86eaa4189282ed315ddfde0094acb5feb1b7314637725a2e73bdc9f7295',1,'tson']]]
];
